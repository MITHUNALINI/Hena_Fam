package com.Henafam.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.Henafam.model.HenaFeedback;
import com.Henafam.repository.HenaFeedbackRepository;


@Service
public class HenaFeedbackService {
	
	HenaFeedbackRepository henaFeedbackRepository;

	public ResponseEntity<List<HenaFeedback>> getAllFeedback() {
		try {
			List<HenaFeedback> feedbacks = henaFeedbackRepository.findAll();
			if(feedbacks.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}else {
				return new ResponseEntity<>(feedbacks,HttpStatus.OK);
			}
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<HenaFeedback> createFeedback(HenaFeedback feedback) {
		try {
			HenaFeedback upFeedback = henaFeedbackRepository.insert(feedback);
			return new ResponseEntity<>(upFeedback ,HttpStatus.CREATED);
			
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<HenaFeedback> getFeedbackById(String feedbackId) {
		try {
			Optional<HenaFeedback> feedback = henaFeedbackRepository.findById(feedbackId);
			if(feedback.isPresent()) {
				return new ResponseEntity<>( feedback.get() , HttpStatus.OK);
			}else {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<List<HenaFeedback>> getFeedbackByProductId(String productId) {
		try {
			List<HenaFeedback> feedback = henaFeedbackRepository.findByProductId(productId);
			if(feedback.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}else {
				return new ResponseEntity<>(feedback ,HttpStatus.OK);
			}
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<Long> countFeedbackByProductId(String pro) {
		try {
			Long totFeedback = henaFeedbackRepository.countByProductId(pro);
			if(totFeedback == 0) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}else {
				return new ResponseEntity<>(totFeedback , HttpStatus.OK);
			}
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
