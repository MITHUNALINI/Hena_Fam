package com.Henafam.service;



import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.CrudRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.Henafam.model.Poultry;
import com.Henafam.repository.PoultryRepository;







@Service
public class PoultryService {
	
	private static final CrudRepository<Poultry, String> poultryReponsitory = null;
	@Autowired
	PoultryRepository poultryRepository;
	private Poultry newPoultry;
	
	

	public ResponseEntity< List<Poultry>> getAllPoultry () {
		try {
			List<Poultry> poultry= poultryRepository.findAll();
			if (poultry.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<> (poultry,HttpStatus.OK);
			} catch (Exception e) {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
	}
	
	public ResponseEntity<Poultry> createpoultry(Poultry poultry) {
	    try {
			Poultry pou = poultryRepository.insert(poultry);
			return new ResponseEntity<>(pou,HttpStatus.CREATED);
		 }catch (Exception e) {
			 return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		 }
}
	public ResponseEntity <Poultry> getPoultryById(String id) {
		Optional<Poultry> poultry =poultryRepository.findById(id);
		if (poultry.isPresent()) {
			return new ResponseEntity<>(poultry.get(),HttpStatus.OK);
		}else {
			return new ResponseEntity<> (HttpStatus.NOT_FOUND);
		}
	}
	
	public ResponseEntity<Poultry> updatePoultry(String id, Poultry poultry) {
		Optional<Poultry> oldPoultry = poultryReponsitory.findById(id);
		if (oldPoultry.isPresent()) {
			Poultry _poultry = oldPoultry.get();
			_poultry.setName(newPoultry.getName());
			_poultry.setDescribtion(newPoultry.getDescribtion());
			_poultry.setPrice(newPoultry.getPrice());
			_poultry.setUrl(newPoultry.getUrl());
			
			return new ResponseEntity<> (poultryRepository.save(_poultry),HttpStatus.OK);
			}else {
				return new ResponseEntity<> (HttpStatus.NOT_FOUND);
			}
	}
	
	public ResponseEntity<HttpStatus>  PoultryById(String id) {
		try {
			poultryRepository.deleteById(id);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	public ResponseEntity<Map<String, Object>> getAllPoultryInPage(int pageNo, int pageSize, String sortBy) {
		try {
			Map<String, Object> response = new HashMap<>();
		    Sort sort = Sort.by(sortBy);
			Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
		    Page<Poultry> page = poultryRepository.findAll(pageable);
		    response.put("data", page.getContent());
		    response.put("Total no of pages", page.getTotalPages());
		    response.put("Total no of elements", page.getTotalElements());
		    response.put("Current page no", page.getNumber());
		    
		    return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception e) {
		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}


}
