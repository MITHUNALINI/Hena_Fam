package com.Henafam.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Henafam.model.HenaFeedback;
import com.Henafam.service.HenaFeedbackService;

@RestController
@RequestMapping("/Feedback")
public class HenaFeedbackController {
	@Autowired
	HenaFeedbackService henaFeedbackService;
	
	@GetMapping
	public ResponseEntity<List<HenaFeedback>> getAllFeedback(){
		return henaFeedbackService.getAllFeedback();
	}
	
	@PostMapping
	public ResponseEntity<HenaFeedback> createFeedback(@RequestBody HenaFeedback feedback){
		return henaFeedbackService.createFeedback(feedback);
	}
	
	@GetMapping("/{feedbackId}")
	public ResponseEntity<HenaFeedback>getFeedbackById(@PathVariable String feedbackId){
		return henaFeedbackService.getFeedbackById(feedbackId);
	}
	
	@GetMapping(params="productId")
	public ResponseEntity<List<HenaFeedback>> getFeedbackByProductId(@RequestParam String productId){
		return henaFeedbackService.getFeedbackByProductId(productId);
	}
	
	@GetMapping(params="pro")
	public ResponseEntity<Long> countFeedbackByProductId(@RequestParam String pro){
		return henaFeedbackService.countFeedbackByProductId(pro);
	}
}


