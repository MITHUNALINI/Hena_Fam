package com.Henafam.controller;



import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Henafam.model.Poultry;
import com.Henafam.service.PoultryService;




@RestController
@RequestMapping ("/poultry")
public class PoultryController {
	
	@Autowired
	PoultryService poultryService;
	

	@GetMapping
	public ResponseEntity< List<Poultry>> getAllPoultry() {
		 return poultryService.getAllPoultry ();
		
	}
	@PostMapping
	public ResponseEntity <Poultry> createPoultry (@RequestBody Poultry poultry){
	   return poultryService.createpoultry(poultry);

     }
	@GetMapping("/{id}")
	  public  ResponseEntity <Poultry> getPoultryById(@PathVariable String id) {
		 return poultryService.getPoultryById(id);
	 }
	 @PutMapping("/{id}")
	 public ResponseEntity<Poultry> updateTutorial(@RequestBody Poultry poultry, @PathVariable String id) {
		return poultryService.updatePoultry(id,poultry);
		 
	 }
	
		
	 @DeleteMapping("/{id}")
	 public ResponseEntity<HttpStatus>  deletePoultry(@PathVariable String id) {
		 return poultryService.PoultryById(id);
	 }
	 @GetMapping("/page")
	    public ResponseEntity<Map<String, Object>> getAllPoultryInPage(
	    		@RequestParam(name = "pageNo", defaultValue = "0") int pageNo, 
	    		@RequestParam(name = "pageSize", defaultValue = "2") int pageSize, 
	    		@RequestParam(name = "sortBy", defaultValue = "id") String sortBy) {
			return poultryService.getAllPoultryInPage(pageNo, pageSize, sortBy);
		}
		
	
}

