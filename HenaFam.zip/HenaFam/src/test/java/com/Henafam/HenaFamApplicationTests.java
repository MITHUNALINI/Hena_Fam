package com.Henafam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HenaFamApplicationTests {

	@Test
	void contextLoads() {
	}

}
